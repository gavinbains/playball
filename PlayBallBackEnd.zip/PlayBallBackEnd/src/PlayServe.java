import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PlayServe
 */
@WebServlet("/PlayServe")
public class PlayServe extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response)
		   	throws ServletException, IOException {
	
		//We will receive calls from the front-end requesting the information about the current user, 
		//or a list of all locations for all games
		String purpose = request.getParameter("purpose");
		if (purpose.compareTo("user_info") == 0) {
			
			//James is asking for a stringified JSON of the User Object
			DataGrabber dg = new DataGrabber("https://hoop2-98f52.firebaseio.com/");
			
			String u_ID = request.getParameter("u_ID");
			String userObj = dg.getUser(u_ID);
			
			
			PrintWriter pw = response.getWriter(); 
			pw.print(userObj);
		}
		else if (purpose.compareTo("locations") == 0){
			//Get all of the locations
			DataGrabber dg = new DataGrabber("https://hoop2-98f52.firebaseio.com/");
			String games = dg.getAllUserLocations();
			
			//turn it into a JSON string
			PrintWriter pw = response.getWriter(); 
			pw.print(games);
			
		}
		
		
		
	
	}

}
